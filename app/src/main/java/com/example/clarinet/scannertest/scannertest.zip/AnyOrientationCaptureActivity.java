package com.example.clarinet.scannertest;

import com.journeyapps.barcodescanner.CaptureActivity;

/**
 * Created by KIM on 2017-12-10.
 */

public class AnyOrientationCaptureActivity extends CaptureActivity {
}
