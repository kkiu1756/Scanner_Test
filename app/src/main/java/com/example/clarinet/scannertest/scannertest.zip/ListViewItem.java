package com.example.clarinet.scannertest;

/**
 * Created by KIM on 2017-12-10.
 */

public class ListViewItem {
    private String bar ;
    private String goods ;
    private String price;
    private String weight;

    public void setBar(String barcode) {
        bar = barcode;
    }
    public void setGoods(String Goods) {
        goods = Goods;
    }

    public void setWeight(String Weight) {
        weight = Weight;
    }
    public void setPrice(String Price) {
        price = Price;
    }

    public String getBar() {
        return this.bar ;
    }
    public String getName() {
        return this.goods ;
    }

    public String getPrice() {
        return this.price ;
    }
    public String getWeight() {
        return this.weight ;
    }
}