package com.example.clarinet.scannertest;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.ResultPoint;
import com.google.zxing.client.android.BeepManager;
import com.google.zxing.integration.android.IntentIntegrator;
import com.journeyapps.barcodescanner.BarcodeCallback;
import com.journeyapps.barcodescanner.BarcodeResult;
import com.journeyapps.barcodescanner.DecoratedBarcodeView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

/**
 * This sample performs continuous scanning, displaying the barcode and source image whenever
 * a barcode is scanned.
 */
public class MainActivity extends Activity {
    private static final String TAG = MainActivity.class.getSimpleName();
    private DecoratedBarcodeView barcodeView;
    private BeepManager beepManager;
    private String lastText;
    private String lastWeight;
    private float totalWeight=0;
    private int totalList=0;

    private String inUrl="http://10.1.248.255:4321/jdbc_test/WebContent/test/android_customer_insert.jsp";
    private String delUrl="http://10.1.248.255:4321/jdbc_test/WebContent/test/android_customer_delete.jsp";
    private InsertAndDelete inDel=new InsertAndDelete(inUrl,delUrl); // jjh

    private int inOrDel;

    ListViewAdapter listAdapter;
    ListView listView;

    AlertDialog.Builder dialog;
    EditText etEdit;

    // 전체 무게 합산 텍스트 뷰
    TextView totalWei;
    // 전체 상품수 합산 텍스트 뷰
    TextView totallist;

    // JSONArray에서 String형변환 객체
    JtoS jtos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //리스트 뷰 어댑터
        listAdapter = new ListViewAdapter();
        listView = (ListView) findViewById(R.id.list_preview);
        listView.setAdapter(listAdapter);

        // 전체무게 합산 텍스트 뷰
        totalWei = (TextView)findViewById(R.id.total_weight);
        // 총 상품수 합산 텍스트 뷰
        totallist = (TextView)findViewById(R.id.total_list);

        // callback
        BarcodeCallback callback = new BarcodeCallback() {
            @Override
            public void barcodeResult(BarcodeResult result) {
                // 중복 바코드 막기
                if(result.getText() == null || result.getText().equals(lastText)) {
                    return;
                }

                // 바코드 변수에 입력
                lastText = result.getText();
                // 스캐너와 리스트 뷰 사이 상태창에 바코드 입력
                barcodeView.setStatusText(result.getText());
                // 삑 소리
                beepManager.playBeepSoundAndVibrate();

                //Added preview of scanned barcode
                // 무게 입력 다이얼로그
                etEdit = new EditText(MainActivity.this);
                dialog = new AlertDialog.Builder(MainActivity.this);
                dialog.setTitle("카트에 물건을 담아주세요.");
                dialog.setView(etEdit);
                // OK 버튼 이벤트
                dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        lastWeight = etEdit.getText().toString();

                        inDel.Insert(lastText);

                        if(Float.parseFloat(lastWeight) > 0){
                            //전체 무게,상품수 추가
                            totalWeight+=Float.parseFloat(lastWeight);
                            totalList++;
                            //전체 무게, 상품수 텍스트 뷰에 출력
                            totalWei.setText("총 무게 : "+(int) totalWeight);
                            totallist.setText("상품 수 : "+(int)totalList);

                        }else{
                            // 바코드만 찍고 무게가 늘어나지 않을때
                            Toast.makeText(MainActivity.this, "바코드 재입력후 물건을 넣어주세요.",Toast.LENGTH_SHORT).show();
                            lastText = null;
                        }
                    }
                });
                dialog.show();

                /*ImageView imageView = (ImageView) findViewById(R.id.barcodePreview);
                imageView.setImageBitmap(result.getBitmapWithResultPoints(Color.YELLOW));*/
            }

            @Override
            public void possibleResultPoints(List<ResultPoint> resultPoints) {
            }
        };

        barcodeView = (DecoratedBarcodeView) findViewById(R.id.barcode_scanner);
        barcodeView.decodeContinuous(callback);
        beepManager = new BeepManager(this);

    }

    @Override
    protected void onResume() {
        super.onResume();

        barcodeView.resume();
    }

    @Override
    protected void onPause() {
        super.onPause();

        barcodeView.pause();
    }

    public class NetworkTask extends AsyncTask<Void, Void, String> {

        private String url;
        private ContentValues values;

        public NetworkTask(String url, ContentValues values) {

            this.url = url;
            this.values = values;
        }

        @Override
        protected String doInBackground(Void... params) {
            String result = null;
            RequestHttpURLConnection requestHttpURLConnection = new RequestHttpURLConnection();
            result = requestHttpURLConnection.request(url, values);
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            //doInBackground()
            //tv_outPut.setText(s);

            if(inOrDel==1)
            {
                try{
                    JSONObject jsonObject=new JSONObject(s);
                    String barcode=(String)jsonObject.get("barcode");
                    String name=(String)jsonObject.get("name");
                    String price = (String)jsonObject.get("price");
                    String weight = (String)jsonObject.get("weight");
                    listAdapter.addItem(barcode, name, price, weight);
                    listAdapter.notifyDataSetChanged();
                }
                catch(Exception e){

                }
            }
           if(inOrDel==0)
           {
               
           }


        }
    }

    public class InsertAndDelete {

        public String InsertUrl;
        public String DeleteUrl;
        public JSONArray result1=null;

        private NetworkTask networkTask;
        final ContentValues contentValues=new ContentValues();

        InsertAndDelete(String InsertUrl,String DeleteUrl){

            this.InsertUrl=InsertUrl;
            this.DeleteUrl=DeleteUrl;
        }
        public void Insert(String barcode){

            if(barcode!=null) {
                contentValues.put("barcode", barcode);

                inOrDel=1;

                networkTask = new NetworkTask(InsertUrl, contentValues);
                networkTask.execute();

            }

        }

        public void Delete(String barcode){
            if(barcode!=null) {
                contentValues.put("barcode", barcode);

                inOrDel=0;
                networkTask = new NetworkTask(DeleteUrl, contentValues);
                networkTask.execute();
            }
        }

        public JSONArray getResult(){
            return result1;
        }
    }
}